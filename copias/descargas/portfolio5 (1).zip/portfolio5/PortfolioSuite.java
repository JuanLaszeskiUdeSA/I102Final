package portfolio5;

import org.junit.platform.suite.api.SelectPackages;
import org.junit.platform.suite.api.Suite;

@Suite
@SelectPackages("portfolio5")
public class PortfolioSuite {

}
