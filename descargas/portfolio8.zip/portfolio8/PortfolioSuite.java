package portfolio8;

import org.junit.platform.suite.api.SelectPackages;
import org.junit.platform.suite.api.Suite;

@Suite
@SelectPackages("portfolio6")
public class PortfolioSuite {

}
